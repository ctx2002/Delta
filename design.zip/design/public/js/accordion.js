var accortion = {
               para : {
                   openedID : 0,
                   clickExpr : "",
                   contentPanelExpr : "",
                   nextTitleExpre : ""
               },
               // expre used to identify content panels --  tags used to hold content.
               "addHash" : function() {
                   
                   if (accortion.para.contentPanelExpr != "") {
	                   
	                   $(accortion.para.contentPanelExpr).each(function(index){
	                       $(this).attr("hash",index);
	                       
	                       if (index != accortion.para.openedID) {
	                           $(this).css("display","none");
	                       }
	                   });
                   }
                   
                   if (accortion.para.clickExpr != "") {
                       $(accortion.para.clickExpr).each(function(index){
                           //you can not set hash attribute, if <a> tag not access customised attributes? 
                           //only test in firefox 3
	                       $(this).attr("id",index);
	                   });    
                   }
                          
               },
               
               "attachToClickItem" : function(){
                   if (accortion.para.contentPanelExpr != "") {
                       $(accortion.para.clickExpr).each(function(index){
                           if (index == accortion.para.openedID) {
                               $(this).html('<img alt="arrow" src="images/circle_arrow_down1.jpg" ></img>');
                               //    
                           } else {
                               
                               $(this).html('<img alt="arrow" src="images/arrowonly.jpg" ></img>');
                               $(this).parents().next( accortion.para.nextTitleExpre).css("background-image","url(images/lightblue.jpg)");
                               $(this).parents().next( accortion.para.nextTitleExpre).css("background-color","rgb(139,205,204)");
                               $(this).parents().next( accortion.para.nextTitleExpre).css("color","rgb(0,142,144)");
                               
                               //alert($(this).parents().next(accortion.para.nextTitleExpre));
                           }
                           
                           $(this).click(function(){
                               var hash = $(this).parents().next(accortion.para.contentPanelExpr).attr("hash");//find next panel's hash value
                               if (hash != accortion.para.openedID) {
                                   //close preciously opened content
                                   $(accortion.para.contentPanelExpr).filter("[hash='"+accortion.para.openedID+"']").css("display","none");
                                   //chanage preciously opened arrow/link
                                   $(accortion.para.clickExpr).filter("[id='"+accortion.para.openedID+"']").html('<img alt="arrow" src="images/arrowonly.jpg" ></img>');
                                   $(accortion.para.clickExpr).filter("[id='"+accortion.para.openedID+"']").parents().next( accortion.para.nextTitleExpre).css("background-image","url(images/lightblue.jpg)");
                                   $(accortion.para.clickExpr).filter("[id='"+accortion.para.openedID+"']").parents().next( accortion.para.nextTitleExpre).css("color","rgb(0,142,144)");
                                   $(accortion.para.clickExpr).filter("[id='"+accortion.para.openedID+"']").parents().next( accortion.para.nextTitleExpre).css("background-color","rgb(139,205,204)");
                                   
                                   $(this).parents().next(accortion.para.contentPanelExpr).css("display","block");
                                  
                                   $(this).html('<img alt="arrow" src="images/circle_arrow_down1.jpg" ></img>');
                                   $(this).parents().next( accortion.para.nextTitleExpre).css("background-image","url(images/corner_tabend_orange1.jpg)");
                                   $(this).parents().next( accortion.para.nextTitleExpre).css("background-color","rgb(227,111,0)");
                                   $(this).parents().next( accortion.para.nextTitleExpre).css("color","#fff");
                                   accortion.para.openedID = hash;
                               }    
                           });
                       });        
                   }    
               },
               "accortion" : function(clickExpr,contentPanelExpr,index,nextTitleExpre){
                   accortion.para.openedID = index;
                   
                   accortion.para.nextTitleExpre = nextTitleExpre;
                   
                   accortion.para.clickExpr = clickExpr;
                   accortion.para.contentPanelExpr =     contentPanelExpr;
                   accortion.addHash();
                   accortion.attachToClickItem();
               }
           };