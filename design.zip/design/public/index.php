<?php
error_reporting(E_ALL);
require_once (realpath(dirname(__FILE__)) . "/../config/const.php");
require_once 'Zend/Controller/Front.php';
require_once dirname(__FILE__) . "/../Library/Loader.php";
require_once 'Zend/Session.php';


//session_start();
$front     = Zend_Controller_Front::getInstance();

//so inside Zend_Controller_Front::dispatch() method will not create a 
//default view render.
//also check code inside Maxum_loader::initView(), i set noViewRenderer to false,
//so zend controller will try to rendering page.


$front->setParam('noViewRenderer',true);
$front->setControllerDirectory(APP_PATH . "controllers");
$front->registerPlugin(new Library_Loader($front));

try {
    $front->dispatch();
    
} catch (Exception $e) {
	var_dump($e->getMessage());
}
?>