<?php
require_once 'Zend/Controller/Action.php';
require_once realpath(dirname(__FILE__)) . "/../Library/Business/Auth.php";
class Application_Controller extends Zend_Controller_Action
{
    protected $isLogin = 0;
	public function init()
    {
    	parent::init();
        $this->view->assign("indexLink","notactive");
    	$this->view->assign("newsLink","notactive");
    	$this->view->assign("recipieLink","notactive");
    	$this->view->assign("mythsLink","notactive");
    	$this->view->assign("successLink","notactive");
    	$this->view->assign("contactLink","notactive");
    	$this->view->assign("faqLink","notactive");
    	$namespace = new Zend_Session_Namespace("site");
    	
    	   if( $namespace->isLegalClient == 1) {
    	       $this->view->assign("showLogout",1);
    	       $this->isLogin = 1;
    	   }
    	
    	if (null != $this->_getParam("openID") && ctype_digit($this->_getParam("openID")) ) {
        	$this->view->assign("openID",$this->_getParam("openID"));
        } else 
            $this->view->assign("openID",0);
    }

    protected function setSiteSession($name,$value)
    {
    	$namespace = new Zend_Session_Namespace("site");//Zend_Session_Namespace is singleton
    	$namespace->$name = $value;
    }
}
?>