<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";
class RecipieController extends Application_Controller
{
    public function init() 
	{
	    parent::init();
        $this->view->assign("recipieLink","activelink");
	}
	
    public function indexAction()
	{
		
	}
}
?>