<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";

class MythsController extends Application_Controller
{
    public function init()
    {
    	parent::init();
    	$this->view->assign("mythsLink","activelink");
    }
    
    public function indexAction()
    {}
}
?>