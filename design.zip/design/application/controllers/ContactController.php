<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Business/Contact.php";
class ContactController extends Application_Controller
{
    public function init()
    {
    	parent::init();
    	$this->view->assign("contactLink","activelink");
    }
    
    public function indexAction()
    {
        $com = new Library_Business_Contact();
        
        $row = $com->loadFromDB();
        $this->view->assign("contact",$row);
        
        //if ( ($row = $com->loadFromDB()) != null);
            
    }
    
    public function headerAction()
    {
    	$this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
    	if ($this->isLogin == 1) {
    	   $com = new Library_Business_Contact();
    	   $com->update(stripslashes($this->_getParam("data")),"header",stripslashes($this->_getParam("cid")));   
    	}
    }
    
    public function bodyAction()
    {
        $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
    	if ($this->isLogin == 1) {
    	   $com = new Library_Business_Contact();
    	   $com->update(stripslashes($this->_getParam("data")),"body",stripslashes($this->_getParam("cid")));   
    	}	
    }
}
?>