<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Form/Faq.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Business/Faq.php";
class FaqController extends Application_Controller
{
    public function init()
    {
    	parent::init();
    	$this->view->assign("faqLink","activelink");
    }
    
    public function indexAction()
    {
         $com  = new Library_Business_Faq();
         $this->view->assign("faqs",$com->showAll());      	
    }
    
    public function addAction()
    {
         if($this->isLogin == 1 ) {
             $this->_helper->getHelper('ViewRender')->setLayoutFileName("/../layouts/popup.phtml");
	         $this->_helper->ViewRender->setScriptAction("add");
			 $form = new Library_Form_Faq("fmFaq",$this->_getAllParams());
             
			 if ($form->validateInput($form->toArray())) {
			 	
	            $form->loadToDb($form->toArray());
				$form->clearFields();
			 } else {
	            if ($form->isSubmittedForm($this->_getAllParams()) )
		            $this->view->assign("showErrorBox",1);
			 }
			 var_dump($form->toArray());
			 $this->view->assign("form",$form->toArray());
         }	
    }
    
    public function headerAction()
    {
    	if ($this->isLogin == 1) {
    	    $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
    		$com = new Library_Business_Faq(); 
            $com->update(stripslashes($this->_getParam("content")),
    	                 "header",
    	                 stripslashes($this->_getParam("id")));	
    	}
    }
    
    public function bodyAction()
    {
        if ($this->isLogin == 1) {
    	    $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
    		$com = new Library_Business_Faq(); 
            $com->update(stripslashes($this->_getParam("content")),
    	                 "body",
    	                 stripslashes($this->_getParam("id")));
             	
    	}
    }
}
?>