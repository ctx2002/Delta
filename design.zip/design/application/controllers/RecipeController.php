<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Business/Recipe.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Form/Recipe.php";
class RecipeController extends Application_Controller
{
    public function init() 
	{
	    parent::init();
        $this->view->assign("recipieLink","activelink");
	}
	
    public function indexAction()
	{
		$com = new Library_Business_Recipe();
        $rows = $com->loadFromDB();
        $this->view->assign("recipes",$rows);
        //openID used for which accordion panel to open
        
	}
	
	public function nameAction()
	{
		$this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
		
	    if ($this->isLogin == 1) {
	    	try {
    	        $com = new Library_Business_Recipe();
    	        $com->update($this->_getParam("content"),$this->_getParam("field"),$this->_getParam("id"));
    	        echo "good";
	    	} catch (Exception $e) {
	    		echo "bad";
	    	}
    	}
		
	}
	
    public function bodyAction()
	{
		$this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
	    if ($this->isLogin == 1) {
    	    $com = new Library_Business_Recipe();
    	    
    	    $com->update(stripslashes($this->_getParam("content")),
    	                 "body",
    	                 stripslashes($this->_getParam("id")));
    	}
	}
	
    public function noteAction()
	{
		$this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
	    if ($this->isLogin == 1) {
    	    $com = new Library_Business_Recipe();
    	    $com->update(stripslashes($this->_getParam("content")),
    	                 "note",
    	                 stripslashes($this->_getParam("id")));   
    	}
	}
	
    public function methodAction()
	{
		$this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
	    if ($this->isLogin == 1) {
    	    $com = new Library_Business_Recipe();
    	    //var_dump($this->_getParam("content"));
    	    $com->update($this->_getParam("content"),
    	                 "method",
    	                 stripslashes($this->_getParam("id")));
    	}
	}
	
	public function addAction()
	{
		if ($this->isLogin == 1) {
        	$this->_helper->getHelper('ViewRender')->setLayoutFileName("/../layouts/popup.phtml");
            $this->_helper->ViewRender->setScriptAction("recipeadd");
		    $form = new Library_Form_Recipe("fmRecipe",$this->_getAllParams(),$_FILES);
		  
	    	if ($form->validateInput($form->toArray()) && $form->moveFile()) {
			    $form->loadToDb($form->toArray());
			    //var_dump($form->toArray());
			    $form->clearFields();
		    } else {
				if ($form->isSubmittedForm($this->_getAllParams()) )
				    $this->view->assign("showErrorBox",1);
		    }
		    
		    $this->view->assign("form",$form->toArray());
		        
    	} 
	}
	
	public function deleteAction()
	{
		$this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
	    if ($this->isLogin == 1) {
	    	try {
    	        $com = new Library_Business_Recipe();
    	        $com->delete($this->_getParam("id"));
    	        
	    	} catch (Exception $e) {
	    		var_dump($e->getMessage());
	    	}
    	}	
	}
	
	public function imageAction()
	{
	    //var_dump($_FILE);
	    $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
	    if ($this->isLogin == 1) {
	        $form = new Library_Form_Recipe("fmRecipe",$this->_getAllParams(),$_FILES);
	        $form->uploadImage($this->_getParam("id"));
	        $this->_redirect("recipe/index/openID/".$this->_getParam("panelIndex"));
	    }	
	}
}
?>