<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";
class ErrorController extends Application_Controller
{
    public function errorAction()
    {
        //var_dump('sssss');
    }
}
?>