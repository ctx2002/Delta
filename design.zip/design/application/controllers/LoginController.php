<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";
require_once "Zend/Session.php";
require_once "Zend/Session/Namespace.php";
require_once "Zend/Auth/Storage/Session.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Business/Auth.php";
class LoginController extends Application_Controller
{
    
    public function indexAction()
    {
    	//if a client logged in we redirect she/he to home page
    	if (Library_Business_Auth::getInstance()->hasIdentity())  {
    	    $this->_redirect("index/index");
    	    exit();
    	} 
    }
    
    public function loginAction()
    {
        $auth = Library_Business_Auth::getInstance()->setName($this->_getParam("name"))->setPassword($this->_getParam("password"));
    	if ( $auth->isValidAuth(Zend_Registry::get('authAdapter')) ) {
    	    $this->setSiteSession("isLegalClient",1);
    	    $this->_redirect("index/index");
    	}
    	else {
    	    $this->_helper->ViewRender->setScriptAction("indexwrong");
    	    $this->view->assign("name",$this->_getParam("name"));
    	    $this->view->assign("password",$this->_getParam("password"));
    	}
    	//var_dump(Library_Business_Auth::getInstance()->hasIdentity());
    }
    
    public function exitAction()
    {
    	Library_Business_Auth::getInstance()->logout();
    	$this->setSiteSession("isLegalClient",0);
    	$this->_redirect("index/index");
    }
    
    public function preDispatch()
    {
    	parent::preDispatch();
    	$auth = Library_Business_Auth::getInstance();
    	$auth->setStorage(new Zend_Auth_Storage_Session('loginAuth'));    
    }
}
?>