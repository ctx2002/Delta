<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/View/PHPTal.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Business/SlimWork.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Form/SlimWork.php";
class IndexController extends Application_Controller
{
    public function init()
    {
    	parent::init();
    	$this->view->assign("indexLink","activelink");
    }
	public function indexAction()
    {
    	/*try {
    		
            $table = new Library_Table_TipComponent();
    	    $tips = $table->fetchAll()->toArray();
    	    $namespace = new Zend_Session_Namespace("site");
    	    $isAdmin = $namespace->isLegalClient;
    	    
    	    $this->view->assign("tips",$tips);
    	    $this->view->assign("showButton",$isAdmin);
    	    
    	} catch (Exception $e) {
    		var_dump($e->getMessage(),$e->getFile(),$e->getLine());
    	}*/
    	
    	$this->_helper->getHelper('ViewRender')->setLayoutFileName("/../layouts/withoutrightbar.phtml");
    	//$this->_helper->ViewRender->setScriptAction("index1");
    }
    
    public function slimworkAction()
    {
        $action = $this->_getParam("method");
        //var_dump($this->_getAllParams());
        if ($action == "add") {
            $this->addSlimWork();	
        } else if ($action == "delete") {
            $this->deleteSimWork($this->_getParam("id")); 	
        } else if ($action == "update") {
            $this->updateSlimWork($this->_getAllParams());	
        } else {
        	$this->display();	
        }	   
    }
    
    private function display()
    {
        $com = new  Library_Business_SlimWork();
        $data = $com->showAll();
        $this->view->assign("slimworks",$data);
        
        if ($this->isLogin == 1) {
        	$t1 = array();
        	foreach ($data as $key => $value) {
        		$t2 = array();
        		foreach ($value as $k=>$v) {
        			if (trim($v) == "") {
        				$t2[$k] = "Missing ".$k;
        			} else
        			    $t2[$k] = $v;			
        		}
        		$t1[$key] = $t2;
        		
        	}
        	
        	$this->view->assign("slimworks",$t1);
            $this->view->assign("showButtons",1);	
        }	
    }
    
    private function updateSlimWork($data)
    {
    	$this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
        if ($this->isLogin == 1) {
         
            $com = new  Library_Business_SlimWork();
            $com->update($data["content"],$data["field"],$data["id"]);
                 	
        }
    }
    
    private function deleteSimWork($id)
    {
    	$this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
        if ($this->isLogin == 1) {
    	    try {
        	    $com = new  Library_Business_SlimWork();
                $com->delete($id);
                
    	    } catch (Exception $e)	{
    	    	
    	    }
        }
    }
    
    private function addSlimWork()
    {
        
        if ($this->isLogin == 1) {
        	$this->_helper->getHelper('ViewRender')->setLayoutFileName("/../layouts/popup.phtml");
            $this->_helper->ViewRender->setScriptAction("slimworkadd");
    	    $form = new Library_Form_SlimWork("fmSlimWork",$this->_getAllParams());
	    	if ($form->validateInput($form->toArray())) {
			    $form->loadToDb($form->toArray());
			    $form->clearFields();
		    } else {
				if ($form->isSubmittedForm($this->_getAllParams()) )
				    $this->view->assign("showErrorBox",1);
		    }
		    
		    $this->view->assign("form",$form->toArray());
		        
    	} 
    }
}
/*
//$this->view->assign("name","anru");
    		//default search path is scripts folder.
    		//$this->_helper->getHelper('ViewRender')->setLayoutFileName("/../layouts/popup.phtml");
    		//var_dump($this->_helper->getHelper('ViewRender'));
    		//$this->_helper->layout()->sidebar = "ccccccccc";
    		//var_dump($this->_helper->getHelper('Form'));
    		//var_dump($this->_helper->ViewRender);
    		//$this->_helper->ViewRender->setScriptAction("index1");
    		//$this->view->assign('isLoggedIn',false);
    		//var_dump(Zend_Registry::get("db"));
    		//var_dump(Zend_Registry::get("site")->isLegalClient);
* */
?>