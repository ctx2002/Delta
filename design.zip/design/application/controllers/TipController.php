<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Business/TipComponent.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Form/TipAdd.php";
class TipController extends Application_Controller
{
	public function init()
	{
		parent::init();
		$namespace = new Zend_Session_Namespace("site");
		if (0 == $namespace->isLegalClient) {
		    $this->_redirect("index/index");
		    exit();	
		}
	}
	public function deleteAction()
	{
	    $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
	    $tip = new Library_Business_TipComponent();
	    $tip->delete(array($this->_getParam("id")));    	
	}
	public function addAction()
	{
		$this->_helper->getHelper('ViewRender')->setLayoutFileName("/../layouts/tipComponent.phtml");
		$form =  new Library_Form_TipAdd("tipAdd",$this->_getAllParams());
		
		if ($form->validateInput($form->toArray())) {
		    $form->loadToDb($form->toArray());
		    $form->clearFields();;
		}
		
		$this->view->assign("tipForm",$form);
	}
	
	public function headerAction()
	{
		$this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
		$tip = new Library_Business_TipComponent();
		//var_dump(stripslashes($this->_getParam("data")));
		$tip->updateTipHeader(stripslashes($this->_getParam("data")),stripslashes($this->_getParam("uid")));
	}
	
	public function titleAction()
	{
	    $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
		$tip = new Library_Business_TipComponent();
		//var_dump(stripslashes($this->_getParam("data")));
		$tip->updateTipTitle(stripslashes($this->_getParam("data")),stripslashes($this->_getParam("uid")));	
	}
	
	public function bodyAction()
	{
	    $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
	    $tip = new Library_Business_TipComponent();
	    echo $this->_getParam("uid");
	    $tip->updateTipBody(stripslashes($this->_getParam("data")),stripslashes($this->_getParam("uid")));		
	}
}
?>