<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Business/Story.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Form/Story.php";
class SuccessController extends Application_Controller
{
    public function init()
    {
    	parent::init();
    	$this->view->assign("successLink","activelink");
    }
    
    public function indexAction()
    {
        $story = new Library_Business_Story();
        $rows = $story->showAll();
        //var_dump($rows);
        $this->view->assign("stories",$rows);
    }
    
    public function deleteAction()
    {
    	if ($this->isLogin == 1) {
    	    $com = new Library_Business_Story(); 
    	    $com-> delete($this->_getParam("id"));    	
    	}
    }
    
    public function addAction()
    {
    	if ($this->isLogin == 1) {
	    	$this->_helper->getHelper('ViewRender')->setLayoutFileName("/../layouts/popup.phtml");
	        $this->_helper->ViewRender->setScriptAction("add");
			$form = new Library_Form_Story("fmRecipe",$this->_getAllParams(),$_FILES);
	        if ($form->validateInput($form->toArray()) && $form->moveFile()) {
	            $form->loadToDb($form->toArray());
				$form->clearFields();
			} else {
	            if ($form->isSubmittedForm($this->_getAllParams()) )
		            $this->view->assign("showErrorBox",1);
			}
			
			$this->view->assign("form",$form->toArray());
    	}
    }
    
    public function headerAction()
    {
        if ($this->isLogin == 1) {
    	    $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
    		$com = new Library_Business_Story(); 
            $com->update(stripslashes($this->_getParam("content")),
    	                 "header",
    	                 stripslashes($this->_getParam("id")));
             	
    	}	
    }
    
    public function titleAction()
    {
        if ($this->isLogin == 1) {
    	    $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
    		$com = new Library_Business_Story(); 
            $com->update(stripslashes($this->_getParam("content")),
    	                 "title",
    	                 stripslashes($this->_getParam("id")));
             	
    	}	
    }
    
    public function bodyAction()
    {
    	if ($this->isLogin == 1) {
    	    $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
    		$com = new Library_Business_Story(); 
            $com->update(stripslashes($this->_getParam("content")),
    	                 "body",
    	                 stripslashes($this->_getParam("id")));
             	
    	}
    }
    
    public function imageAction()
	{
		
		    $this->_helper->getHelper('ViewRender')->setLayoutFileName(null);
		    if ($this->isLogin == 1) {
		    	var_dump($_FILES); 
		        $form = new Library_Form_Story("fmStory",$this->_getAllParams(),$_FILES);
		        $form->uploadImage($this->_getParam("id"));
		        $this->_redirect("success/index");
		    }
			
	}
    
}
?>