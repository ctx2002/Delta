<?php
require_once realpath(dirname(__FILE__)) . "/../Controller.php";
require_once realpath(dirname(__FILE__)) . "/../../Library/Form/Franchise.php";
class FranchiseController extends Application_Controller
{
    public function indexAction()
    {
        $form =  new Library_Form_Franchise("fmFranchise",$this->_getAllParams());
        if ($form->validateInput($form->toArray())) {
		    $form->loadToDb($form->toArray());
		    $form->sendEmail($form->toArray());
		    $form->clearFields();
		} else {
			if ($form->isSubmittedForm($this->_getAllParams()) )
			    $this->view->assign("showErrorBox",1);
		}
		$this->view->assign("form",$form->toArray());
    }	
}
?>