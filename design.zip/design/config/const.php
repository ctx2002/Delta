<?php
define ("APP_PATH", realpath(dirname(__FILE__)) . "/../application/" );
define ("LIB_PATH", realpath(dirname(__FILE__)) . "/../Library/" );
?>