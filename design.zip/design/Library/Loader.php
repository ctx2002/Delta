<?php
require_once "Zend/Controller/Plugin/Abstract.php";
require_once "View/PHPTal.php";
require_once "Zend/Controller/Action/HelperBroker.php";
require_once "Zend/Db/Table/Abstract.php";
require_once "Zend/Layout.php";
//require_once dirname(__FILE__) . "/Table/Session.php";
//require_once "Session.php";
require_once "ViewRender.php";
require_once "Zend/Registry.php";
require_once 'Zend/Config/Ini.php';
require_once 'Zend/Session/Namespace.php';
require_once 'Zend/Auth/Adapter/DbTable.php';
require_once 'Zend/Session/SaveHandler/DbTable.php';
require_once 'Zend/Session.php';

class Library_Loader extends Zend_Controller_Plugin_Abstract 
{
    protected $frontController = null;
    protected $config = null;
    protected $authNameSpace = null;
	public function __construct(Zend_Controller_Front $front,$config = array())
    {
        if ($front == null) {
        	throw new Zend_Exception ("Front controller can not be null.");
        }
    	$this->frontController = $front;
    	$options['nestSeparator'] = ':';	
    }
	public function routeStartup(Zend_Controller_Request_Abstract $request)
    {
    	//loading has order, config must load first
    	$this->loadConfig()->setupDB()
             ->initSession()
             ->initView()->initAuth()->initNamespace();	
    }
    
    public function postDispatch()
    {
        //var_dump($this->getResponse());
        //var_dump($this->config->webhost); 
        //var_dump($this->config->maxumsystem->webhost);   
    }
    
    protected function loadConfig()
    {
    	$section = $_SERVER['SERVER_NAME'];
    	$this->config = new Zend_Config_Ini(dirname(__FILE__).'/../config/config.ini',$section);
    	
    	return $this;	
    }

    
    protected function setupDB()
    {
    	require_once 'Zend/Db.php';
        try {
			$db = Zend_Db::factory('PDO_MYSQL', array(
			    'host'     => $this->config->dbhost,
			    'username' => $this->config->dbusername,
			    'password' => $this->config->dbpassword,
			    'dbname'   => $this->config->dbname
			));
			Zend_Registry::set('db', $db);
			Zend_Db_Table_Abstract::setDefaultAdapter($db);
        } catch (Zend_Exception $e) {
             //TODO: logging error
             var_dump($e->getMessage());	
        }
        return $this;
    }

    protected function initView()
    {
    	$config = array("templatepath" => $this->config->templatepath);
    	$view = new Library_View_PHPTal($config);
    	$view->setEncoding("UTF-8");
    	$view->assign('config',$this->config);
    	$viewRender = new Library_ViewRender();
    	$viewRender->setView($view);
        Zend_Controller_Action_HelperBroker::addHelper($viewRender);
        //Zend_Controller_Action_HelperBroker::addPrefix("Maxum_ControllerActionHelper");
        $this->frontController->setParam('noViewRenderer',false);
        Zend_Controller_Action_HelperBroker::addPath(dirname(__FILE__) ,"Library");
        
        return $this;	
    }
    
    protected function initAuth()
    {
        $authAdapter = new Zend_Auth_Adapter_DbTable(Zend_Registry::get("db"));
        $authAdapter->setCredentialColumn("password")
                    ->setTableName("client")
                    ->setIdentityColumn("name")
                    ->setCredentialTreatment("MD5(?)");
        Zend_Registry::set('authAdapter',$authAdapter );
        
    	return $this;
    }
    
    protected function initSession()
    {
    	$config = array(
            'name'           => 'session',
            'primary'        => 'id',
            'modifiedColumn' => 'modified',
            'dataColumn'     => 'data',
            'lifetimeColumn' => 'lifetime'
        );
        Zend_Session::setSaveHandler(new Zend_Session_SaveHandler_DbTable($config));
        try {
        Zend_Session::start();
        
        } catch (Exception $e) {
        	var_dump($e->getMessage());
        }
        return $this;
    }
    protected function initNamespace()
    {
        //Zend_Session
        //Zend_Session::regenerateId();
    	$namespace = new Zend_Session_Namespace("site");
    	
    	//Zend_Registry::set("site", $namespace);	
    	return $this;
    }
}
?>