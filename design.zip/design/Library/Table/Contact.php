<?php
require_once 'Zend/Db/Table/Abstract.php';
class Library_Table_Contact extends Zend_Db_Table_Abstract
{
	protected $_name = 'contact';
	protected $_primary = 'id';
}
?>