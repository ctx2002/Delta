<?php
require_once 'Zend/Db/Table/Abstract.php';
class Library_Table_Franchise extends Zend_Db_Table_Abstract
{
	protected $_name = 'franchise';
	protected $_primary = 'id';
}
?>