<?php
require_once 'Zend/Controller/Action/Helper/ViewRenderer.php';
class Library_ViewRender extends Zend_Controller_Action_Helper_ViewRenderer
{
	protected $_layoutFileName = '/../layouts/layout.phtml';

        public function setLayoutFileName($name)
        {
            //zend view will search this script within application/views/scripts directory
        	$this->_layoutFileName = $name;
        }

        public function renderScript($script,$name=null)
        {
        	   /*
                    $script is a path.
                    for example:
                        when we access index/index,  that means calling index method inside index controller.
                        the $script will be index/index.phtml 
               *     */
        	   if ($this->_layoutFileName == null) {
        	   	   //if set layoutFileName to null, render will not be called.
        	   	   //a good usage for set lay out file name as null is for ajax call that only want 
        	   	   // return a string of xml or json.
                   $this->setNoRender();
                   return;            	   	
        	   } 
        	   if($name===null)
                        $name = $this->getResponseSegment();
                $this->view->assign('LAYOUT_CONTENT',$script);
                $this->getResponse()->appendBody(
                        $this->view->render($this->_layoutFileName),
                        $name
                );
                $this->setNoRender();
        }

        public function getName()
        {
            return "ViewRender";
        }
	
}
?>