<?php

interface PHPTAL_Tales
{
}

?>
