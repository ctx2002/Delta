<?php
require_once "Zend/View/Abstract.php";
require_once "PHPTAL.php";
class Library_View_PHPTal extends Zend_View_Abstract
{
    protected $_engine = null;
    protected $templatePath = "/tmp/";
    public function __construct($config = array())
    { 
    	$this->_engine = new PHPTAL();
    	$this->_engine->setEncoding("UTF-8");
        $this->_engine->setPhpCodeDestination($this->templatePath);
        $this->_engine->getPhpCodeDestination();
        parent::__construct($config);
    }
    
    private function loadEnvironment($config = array())
    {
    	if (isset($config['templatepath']) && trim($config['templatepate']) != "") {
    	    $this->templatePath = 	$config['templatepate'];
    	}
    }

    public function getEngine()
    {
        return $this->_engine;
    }

    public function assign($spec, $value = null)
	{
	    $this->_engine->set($spec,$value);
	    //$this->_engine->$spec = $value;
    }
    
    protected function _run()
    {
    	$this->_engine->setTemplate(func_get_arg(0));
        echo $this->_engine->execute();
    }   
}
?>