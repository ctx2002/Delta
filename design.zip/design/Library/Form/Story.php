<?php
require_once "Abstract.php";
require_once "Rule/Story.php";
require_once realpath(dirname(__FILE__)) . "/../Business/Story.php";
class Library_Form_Story extends Library_Form_Abstract
{
    protected $imageData;
	public function __construct($name,$postData,$imageData)
    {
    	parent::__construct($name,$postData);
    	$this->imageData = $imageData;
    	$this->attachFormValidateRuleClass("Library_Form_Rule_Story");
    }

    public function setUpFieldName()
    {
    	$this->fields['header'] = '';
    	$this->fields['title'] = ''; 
    	$this->fields['body'] = '';
    	$this->fields['image'] = ''; 	
    }
    
    public function isSubmittedForm($postData)
    {
    	if (isset($postData["subStory"]))
    	    return true;
    	
    	return false;
    }
    
    public function moveFile()
    {
    	$success = false;
    	$dir = realpath(dirname(__FILE__)) . "/../../public/images/";
    	//var_dump($dir,$this->imageData["image"]);
    	if (isset($this->imageData["image"])) {
    	    $uploadfile = $dir . basename($this->imageData["image"]['name']);
    	    if (move_uploaded_file($this->imageData["image"]['tmp_name'], $uploadfile) ) {
    	    	$this->fields['image'] = "images/".$this->imageData["image"]['name'];
    	    	return true;
    	    }  	
    	}
    	return $success;
    }
    
    public function uploadImage($id)
    {
    	$this->moveFile();
    	$com = new Library_Business_Story();
    	//var_dump($this->fields['image']);
    	$com->update($this->fields['image'],"image",$id);
    }
    
    public function loadToDB($data)
    {
       $com = new Library_Business_Story();
       $com->add($data);		
    }
}
?>