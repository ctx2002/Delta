<?php
require_once "Abstract.php";
require_once "Rule/LoginRule.php";
class Library_Form_Login extends Library_Form_Abstract
{
	public $isLoggedIn = false;
	public function __construct($name)
    {
    	parent::__construct($name);
    	$this->attachFormValidateRuleClass("Maxum_Form_Rule_LoginRule");
    }
	public function setUpFieldName()
    {
    	$this->fields['pass'] = '';
    	$this->fields['name'] = '';
    }
}
?>