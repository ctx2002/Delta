<?php
require_once "Abstract.php";
require_once "Rule/Faq.php";
require_once realpath(dirname(__FILE__)) . "/../Business/Faq.php";
class Library_Form_Faq extends Library_Form_Abstract
{
    
	public function __construct($name,$postData)
    {
    	parent::__construct($name,$postData);
    	$this->attachFormValidateRuleClass("Library_Form_Rule_Faq");
    }

    public function setUpFieldName()
    {
    	$this->fields['header'] = '';
    	$this->fields['body'] = '';
    }
    
    public function isSubmittedForm($postData)
    {
    	if (isset($postData["subFaq"]))
    	    return true;
    	
    	return false;
    }
    
    
    public function loadToDB($data)
    {
       $com = new Library_Business_Faq();
       $com->add($data);		
    }
}
?>