<?php
interface Library_Form_IFormValidator
{
	public function validateInput($userInput);
}
?>