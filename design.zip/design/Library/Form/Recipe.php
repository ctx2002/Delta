<?php
require_once "Abstract.php";
require_once "Rule/Recipe.php";
require_once realpath(dirname(__FILE__)) . "/../Business/Recipe.php";
class Library_Form_Recipe extends Library_Form_Abstract
{
    protected $imageData;
	public function __construct($name,$postData,$imageData)
    {
    	parent::__construct($name,$postData);
    	$this->imageData = $imageData;
    	$this->attachFormValidateRuleClass("Library_Form_Rule_Recipe");
    }

    public function setUpFieldName()
    {
    	$this->fields['name'] = '';
    	$this->fields['note'] = ''; 
    	$this->fields['body'] = '';
    	$this->fields['method'] = '';
    	$this->fields['image'] = ''; 	
    }
    
    public function isSubmittedForm($postData)
    {
    	if (isset($postData["subRecipe"]))
    	    return true;
    	
    	return false;
    }
    
    public function moveFile()
    {
    	/*
          array
  'name' => string 'ANZ-small.jpg' (length=13)
  'type' => string 'image/jpeg' (length=10)
  'tmp_name' => string '/Applications/MAMP/tmp/php/phpMN0uoE' (length=36)
  'error' => int 0
  'size' => int 1292

* */
    	$success = false;
    	$dir = realpath(dirname(__FILE__)) . "/../../public/images/";
    	//var_dump($dir,$this->imageData["image"]);
    	if (isset($this->imageData["image"])) {
    	    $uploadfile = $dir . basename($this->imageData["image"]['name']);
    	    if (move_uploaded_file($this->imageData["image"]['tmp_name'], $uploadfile) ) {
    	    	$this->fields['image'] = "images/".$this->imageData["image"]['name'];
    	    	return true;
    	    }  	
    	}
    	return $success;
    }
    
    public function uploadImage($id)
    {
    	$this->moveFile();
    	$com = new Library_Business_Recipe();
    	//var_dump($this->fields['image']);
    	$com->update($this->fields['image'],"image",$id);
    }
    
    public function loadToDB($data)
    {
       $com = new Library_Business_Recipe();
       $com->add($data);		
    }
}
?>