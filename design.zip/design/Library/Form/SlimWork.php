<?php
require_once "Abstract.php";
require_once "Rule/SlimWork.php";
require_once realpath(dirname(__FILE__)) . "/../Business/HeaderBody.php";
class Library_Form_SlimWork extends Library_Form_Abstract
{
    public function __construct($name,$postData)
    {
    	parent::__construct($name,$postData);
    	$this->attachFormValidateRuleClass("Library_Form_Rule_SlimWork");
    }

    public function setUpFieldName()
    {
    	$this->fields['header'] = '';
    	$this->fields['type'] = ''; 
    	$this->fields['body'] = '';
    	$this->fields['title'] = '';  	
    }
    
    public function isSubmittedForm($postData)
    {
    	if (isset($postData["subSlimWork"]))
    	    return true;
    	
    	return false;
    }
    
    public function loadToDB($data)
    {
       $com = new Library_Business_HeaderBody($data["type"]);
       $com->add($data);		
    }
}
?>