<?php
require_once "Abstract.php";
require_once "Rule/TipAddRule.php";
require_once realpath(dirname(__FILE__)) . "/../Business/TipComponent.php";
class Library_Form_TipAdd extends Library_Form_Abstract
{
	public function __construct($name,$postData)
    {
    	parent::__construct($name,$postData);
    	$this->attachFormValidateRuleClass("Library_Form_Rule_TipAddRule");
    }
	public function setUpFieldName()
    {
    	$this->fields['tip_header'] = '';
    	$this->fields['tip_title'] = '';
    	$this->fields['tip_body'] = '';
    }
    
    public function isSubmittedForm($postData)
    {
    	if (isset($postData["tip_sub"]) && $postData["tip_sub"] == "Submit")
    	    return true;
    	
    	return false;
    }
    
    public function loadToDb($data)
    {
        $com = new Library_Business_TipComponent();
        $com->loadToDB($data);	
    }
    
  
}
?>