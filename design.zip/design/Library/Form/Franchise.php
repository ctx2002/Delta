<?php
require_once "Abstract.php";
require_once "Rule/Franchise.php";
require_once realpath(dirname(__FILE__)) . "/../Business/Franchise.php";
class Library_Form_Franchise extends Library_Form_Abstract
{
    public function __construct($name,$postData)
    {
    	parent::__construct($name,$postData);
    	$this->attachFormValidateRuleClass("Library_Form_Rule_Franchise");
    }

    public function setUpFieldName()
    {
    	$this->fields['title'] = '';
    	$this->fields['name'] = '';
    	$this->fields['town'] = '';
    	$this->fields['email'] = '';
    	$this->fields['phone'] = '';
    	$this->fields['interest'] = '';
    }
    
    public function isSubmittedForm($postData)
    {
    	if (isset($postData["subFranchise"]))
    	    return true;
    	
    	return false;
    }
    
    public function loadToDB($data)
    {
       $com = new Library_Business_Franchise($data);
       $com->loadToDB();		
    }
    
    public function sendEmail($data)
    {
        $com = new Library_Business_Franchise($data);
        $com->sendEmail();
    }
    
}
?>