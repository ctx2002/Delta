<?php
require_once "IFormValidator.php";
abstract class Library_Form_Abstract implements Library_Form_IFormValidator
{
	protected $formRules = array();
	protected $fields = array();
	protected $formName = '';
	protected $isValidForm = false;
	protected $isSubmitted = false;
	public function __set($name, $value)
	{
		if (!array_key_exists($name,$this->fields)) throw new Exception("property ". $name . " not exist.");
	    
		$this->fields[$name] = $value;
	}
	
	public function __get($name)
	{
	    if (!array_key_exists($name,$this->fields)) throw new Exception("property ". $name . " not exist.");
	    return 	$this->fields[$name];
	}
	
	public function __construct($name,$postData)
	{
	    $this->formName = $name;
	    $this->setUpFieldName();
	    if ($this->isSubmittedForm($postData))
    	    $this->setSubmittedForm(true);
    	$this->loadFromArray($postData);	
	}
	
	public function isValidForm()
	{
		return $this->isValidForm;
	}
	
	public function generateID()
	{
		//TODO: need to use UUID, this function has high changce to 
		//      generate same id on Cluster environment
		return md5(uniqid(rand(), true));
	}
	/*
        form rule class's method must follow name conversion.
        for example:
        method name must be same as form field name.
        in a form we have a field.
        <input name="name" type="textbox" />
        then in rule class, if we want to validate that field's value.
        we must have a public method:
        public function name($value)
    * */
	public function attachFormValidateRuleClass($ruleClass)
	{
	   $this->formRules[] = $ruleClass;
	}
	
	/*
        post condition: return true on good input, false on bad input
                        LoginRule was created.
        exception: reflection may throw exception on no class found
    *    */
	public function validateInput($userInput)
	{
		//$valid = false;//at start , form is false;
		
		//$allFields = $this->toArray();
		foreach ($this->formRules as $ruleClassName) {
			$class = new ReflectionClass($ruleClassName);
		    foreach ($userInput as $fieldName => $value)
		    if ($class->hasMethod($fieldName)) {
		       
		    	$reflectionMethod = $class->getMethod($fieldName);
		        $this->isValidForm = $reflectionMethod->invokeArgs($class->newInstance(),array($value));
		        if (!$this->isValidForm) return false;
		        //if ($isValid) $valid = $valid && $isValid;
		    }	
		}
		
		return $this->isValidForm;
	}
	
	public function loadFromArray($fields)
	{
		foreach ($fields as $name => $value) {
			if (isset($this->fields[$name]))
			    $this->fields[$name] = $value;
		}
	}
	
	public function toArray()
	{
		return $this->fields;
	}
	
	/*public function isSubmittedForm()
	{
	    return $this->isSubmitted;	
	}*/
	
	public function setSubmittedForm($value)
	{
		$this->isSubmitted = $value;
	}
	
	public function showErrorMessage()
	{
		if (!$this->isValidForm() && $this->isSubmitted)
		    return true;
		return false;
	}
	
	public function clearFields()
	{
		$this->setUpFieldName();
	}
	
	abstract function isSubmittedForm($postData);
	abstract function setUpFieldName();
}
?>