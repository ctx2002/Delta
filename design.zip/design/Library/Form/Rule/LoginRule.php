<?php
class Library_Form_Rule_LoginRule
{
	public function name($value)
	{
		//TODO: write actul filter
		
		return true;
	}
	
	public function pass($value)
	{
		//TODO: write actul filter
		return true;
	}
}
?>