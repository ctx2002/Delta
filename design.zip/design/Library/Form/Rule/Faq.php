<?php
class Library_Form_Rule_Faq
{
	public function body($value)
	{
	    if (trim($value) != "") return true;
		return false;	
	}
	
    public function header($value)
	{
	    //header is location + name
		if (trim($value) != "") return true;
		
		return false;	
	}
}
?>