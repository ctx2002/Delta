<?php
require_once realpath(dirname(__FILE__)) . "/../TipAdd.php";
class Library_Form_Rule_TipAddRule
{
	public function tip_body($value)
	{
		//TODO: write actul filter
		
		return true;
	}
	
	public function tip_title($value)
	{
		
		return true;
	}
	
	public function tip_header($value)
	{
		if (trim($value) == "") return false;    
	    return true;
	}
}
?>