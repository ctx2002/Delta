<?php
class Library_Form_Rule_Recipe
{
	
	public function note($value)
	{
		return true;
	}
	
	public function body($value)
	{
	    if (trim($value) != "") return true;
		
		return false;	
	}
	
    public function name($value)
	{
	    if (trim($value) != "") return true;
		
		return false;	
	}
	
	public function method($value)
	{
		return true;
	}
	
    public function image($value)
	{
		return true;
	}
	
}
?>