<?php
class Library_Form_Rule_SlimWork
{
	
	public function header($value)
	{
		if (trim($value) != "") return true;
		
		return false;
	}
	
	public function body($value)
	{
	    if (trim($value) != "") return true;
		
		return false;	
	}
	
    public function title($value)
	{
	    if (trim($value) != "") return true;
		
		return false;	
	}
	
	public function type($value)
	{
		 if (trim($value) == "slimwork") return true;
		
		return false;	
	}
}
?>