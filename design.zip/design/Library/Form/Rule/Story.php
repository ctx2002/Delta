<?php
class Library_Form_Rule_Story
{
	public function body($value)
	{
	    if (trim($value) != "") return true;
		return false;	
	}
	
    public function header($value)
	{
	    //header is location + name
		if (trim($value) != "") return true;
		
		return false;	
	}
	
	public function title($value)
	{
		//title is name
		if (trim($value) != "") return true;
		
		return false;	
	}
	
    public function image($value)
	{
		return true;
	}
	
}
?>