<?php
class Library_Form_Rule_Franchise
{
	/*
       $this->fields['title'] = '';
    	$this->fields['name'] = '';
    	$this->fields['town'] = '';
    	$this->fields['email'] = '';
    	$this->fields['phone'] = '';
    	$this->fields['interest'] = '';
* */
	
	public function title($value)
	{
		if (trim($value) != "") return true;
		
		return false;
	}
	
	public function name($value)
	{
	    if (trim($value) != "") return true;
		
		return false;	
	}
	
	public function town($value)
	{
		 if (trim($value) != "") return true;
		
		return false;	
	}
	
	public function email($value)
	{
		if (strpos($value,"@") === FALSE) return false;
		
		return true;
	}
	
	public function interest($value)
	{
		return true;
	}
}
?>