<?php
require_once realpath(dirname(__FILE__)) . "/../Business/HeaderBody.php";
class Library_Business_Faq extends Library_Business_HeaderBody
{
	public function __construct()
	{
		parent::__construct("faq");
	}
}
?>