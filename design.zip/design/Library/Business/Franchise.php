<?php
require_once realpath(dirname(__FILE__)) . "/../Table/Franchise.php";
require_once ("Zend/Mail.php");
require_once ("Zend/Mail/Transport/Smtp.php");

class Library_Business_Franchise
{
    protected $formData;
    
	public function __construct($formData)
    {
        $this->formData = $formData;
    }
	public function loadToDB()
    {
        try {
		    $table = new Library_Table_Franchise();
		    $table->insert($this->formData);	
		} catch (Exception $e) {
		    var_dump($e->message());	
		}
    }

    public function sendEmail()
    {
        $str = $this->fillEmailTemplate();
        
        try {
        //$tr = new Zend_Mail_Transport_Smtp('smtp.vodafone.co.nz');
        //Zend_Mail::setDefaultTransport($tr);
        /*$mail = new Zend_Mail();
        $mail->setBodyText($str)
             ->setFrom('shaoyong@ihug.co.nz', 'Anru chen')
             ->setSubject('Franchise Enquiry')
             ->addTo('ctx2002@gmail.com', 'Me')
             ->send();*/
        } catch (Exception $e) {
        	var_dump($e->getMessage());
        }    	
    }
    
    protected function fillEmailTemplate()
    {
        $fileName = realpath(dirname(__FILE__)) . "/emailTemplate/franchise.txt";
        $str = file_get_contents  ( $fileName );
        $result = "";
        if (FALSE !== $str) {
        	$i = 0;
        	foreach ($this->formData as $key => $value) {
        		$patterns[$i] = "%{".$key."}%";
        		$replacements[$i] = $value;
        		++$i;
        	}
         	$result = preg_replace($patterns, $replacements, $str);
        }

        return $result;
    }
}
?>