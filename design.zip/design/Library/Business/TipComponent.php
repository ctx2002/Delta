<?php
require_once realpath(dirname(__FILE__)) . "/../Table/TipComponent.php";
class Library_Business_TipComponent
{	
	protected $isAdmin = 0;
	protected $header;
	protected $title;
	protected $body;
	protected $id;
	public function __construct($isAdmin = 0)
	{
		$this->isAdmin = $isAdmin;
	}
	
	public function getId()
	{
		$this->id;
	}
	public function addTipHeader($header)
	{
		$this->header = $header;
	}
	
	public function isAdmin()
	{
		return $this->isAdmin;
	}
	
	public function getTipHeader()
	{
		return $this->header;
	}

	public function deleteTip($id)
	{}
	
	public function addTipBody($bodyText)
	{
		$this->body = $bodyText;
	}
	
	public function getTipBody()
	{
		$this->body;
	}
	
	public function addTitle($title)
	{
		$this->title = $title;
	}
	public function getTitle()
	{
		$this->title;
	}
	public function updateTipHeader($header,$id)
	{
	    try {
	    	$this->update("tip_header",$header,$id);
        }  catch (Exception $e)	{
	    	var_dump($e->message());
	    }	
		//$this->update("tip_header",$title,$id);
	}
	
	public function updateTipBody($bodyText,$id)
	{
		try {
	    	$this->update("tip_body",$bodyText,$id);
        }  catch (Exception $e)	{
	    	var_dump($e->message());
	    }	
	}
	
	public function updateTipTitle($title,$id)
	{
	    try {
	    	$this->update("tip_title",$title,$id);
        }  catch (Exception $e)	{
	    	var_dump($e->message());
	    }	
	}
	
	protected function update($col,$text,$id)
	{
	    $table = new Library_Table_TipComponent();
	    $where = $table->getAdapter()->quoteInto('id = ?', $id);
	    $data = array($col => $text);
	   
	    $table->update($data, $where);		
	}
	
	public function fromArray($tipFromDb)
	{
		$this->title = $tipFromDb['title'];
		$this->body = $tipFromDb['body'];
		$this->header = $tipFromDb['header'];
		$this->id = $tipFromDb['id'];		
	}
	
	public function loadToDB($data)
	{
		try {
		    $table = new Library_Table_TipComponent();
		    $table->insert($data);	
		} catch (Exception $e) {
		    var_dump($e->message());	
		}
	}
	public function delete($ids)
	{
	    try {
		    $table = new Library_Table_TipComponent();
		    foreach ($ids as $key => $id) {
		    	//echo $id;
		        $where = $table->getAdapter()->quoteInto('id = ?', $id);
		        $table->delete($where);
		    }
		} catch (Exception $e) {
		    var_dump($e->message());	
		}	
	}
	public function fetchAllTipsForView()
	{
	    $table = new Library_Table_TipComponent();
    	$tips = $table->fetchAll()->toArray();
    	return $tips;
	}
}
?>