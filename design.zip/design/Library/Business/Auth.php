<?php
require_once ("Zend/Session.php");
require_once ("Zend/Auth.php");
class Library_Business_Auth extends Zend_Auth
{
	protected $name;
	protected $password;
	protected $authResult;
	/*public function __construct($name,$password)
	{
	    $this->name = $name;
	    $this->password = $password;	
	}*/
	
    public static function getInstance()
    {
        if (null === self::$_instance) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }
	
	public function setName($name)
	{
		$this->name = $name;
		return $this;
	}
	
	public function setPassword($pass)
	{
		$this->password = $pass;
		return $this;
	}
	
	public function isValidAuth($authAdapter)
	{
	   try {
		    $authAdapter->setIdentity($this->name)->setCredential($this->password);
	        $result = $this->authenticate($authAdapter);
	        $this->authResult = $result;
	        return $result->isValid();
	    } catch (Zend_Auth_Adapter_Exception $e) {
	    	//echo "answering the authentication query is impossible";
	    	//var_dump($e);
	    	//var_dump($this->name);
	    }
	}
	
	public function logout()
	{
	    $this->clearIdentity();
	}
	
}
?>