<?php
require_once realpath(dirname(__FILE__)) . "/../Table/Recipe.php";
class Library_Business_Recipe
{
	public function loadFromDB()
	{
		$table = new Library_Table_Recipe();
    	$rows = $table->fetchAll();
    	return $rows->toArray();
	}
	
	public function updateHeader($content,$id)
	{
		$this->update($content,"header",$id);
	}
	
    public function updateBody($content,$id)
	{
		$this->update($content,"body",$id);
	}
	
    public function updateNote($content,$id)
	{
		$this->update($content,"note",$id);
	}
	
    public function updateMethod($content,$id)
	{
		$this->update($content,"method",$id);
	}
	
    public function update($content,$column,$id)
    {
    	
    	    try {
    	       $table = new Library_Table_Recipe();
        
	           $where = $table->getAdapter()->quoteInto('id = ?', $id);
	           $data = array($column => $content);
	           
	           $table->update($data, $where);	
    	    } catch (Exception $e)	 {
    	    	var_dump($e->getMessage());
    	    }
    	
    }
    
    public function delete($id)
    {
        $table = new Library_Table_Recipe();
	    $where = $table->getAdapter()->quoteInto('id = ?', $id);
	    $table->delete($where);		
    }
    
    
    public function add($data)
	{
	    try {
	    	//$temp = preg_replace("/\r\n/","<br>",$data['body']);
	    	//$data['body'] = $temp;
	    	$table = new Library_Table_Recipe();
	    	$temp = array();
	    	foreach ($data as $key => $value) {
	    	    $temp[$key] = preg_replace("/\r\n/","<br/>",$data[$key]);    	
	    	}
		    $table->insert($temp);	
		} catch (Exception $e) {
		    var_dump($e->message());	
		}
	}
   
}
?>