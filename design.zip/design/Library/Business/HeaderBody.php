<?php
require_once realpath(dirname(__FILE__)) . "/../Table/HeaderBody.php";
class Library_Business_HeaderBody
{
	protected $type= "";
	protected $table = null;
	public function __construct($type)
	{
		
	    try {
		    $this->type = $type;
		    $this->table = new Library_Table_HeaderBody();
		} catch (Exception $e) {
		    var_dump($e->message());	
		}
	}
	
	public function showAll()
	{
		try {
		$rows = $this->table->fetchAll("type='".$this->type."'");
		return $rows->toArray();
		} catch (Exception $e) {
			var_dump($e->getMessage());
		}
	}
	public function add($data)
	{
	    try {
	    	$temp = preg_replace("/\r\n/","<br/>",$data['body']);
	    	$data['body'] = $temp;
	    	$data["type"] = $this->type;
		    $this->table->insert($data);	
		} catch (Exception $e) {
		    var_dump($e->message());	
		}
	}
	
	public function delete($id)
	{
	    try {
	    	$where = $this->table->getAdapter()->quoteInto('id = ?', $id);
		    $this->table->delete($where);	
		} catch (Exception $e) {
		    var_dump($e->message());	
		}	
	}

    public function update($content,$column,$id)
    {
	    $where = $this->table->getAdapter()->quoteInto('id = ?', $id);
	    $data = array($column => $content);
	    $this->table->update($data, $where);			
    }
}
?>