<?php
class Library_Business_TipComponent
{
    public function __construct()
    {
    	
    }
	public function addPicture()
    {
        	
    }
    
    public function modifyPicture($id)
    {}

    public function modifyHeader($text,$id)
    {}
    
    public function modifyParagraph($text,$id)
    {}
    
    public function addParagraph($text,$id)
    {}
    
}
?>