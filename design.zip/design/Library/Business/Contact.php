<?php
require_once realpath(dirname(__FILE__)) . "/../Table/Contact.php";

class Library_Business_Contact
{
    
	public function __construct()
    {
        
    }
	public function loadToDB()
    {
        try {
		    $table = new Library_Table_Franchise();
		    $table->insert($this->formData);	
		} catch (Exception $e) {
		    var_dump($e->message());	
		}
    }
    
    public function loadFromDB()
    {
    	try {
    	    $table = new Library_Table_Contact();
    	    $rows = $table->fetchAll();//contact table only has one item at all time
            if ($rows->count() > 0) return $rows[0]->toArray();
    	} catch (Exception $e) {
    	    var_dump($e-getMessage());
        }
        
    	return null;
    }
    
    public function update($content,$column,$id)
    {
        $table = new Library_Table_Contact();
        
	    $where = $table->getAdapter()->quoteInto('id = ?', $id);
	    $data = array($column => $content);
	    $table->update($data, $where);		
    	
    }
}
?>