<?php
require_once dirname(__FILE__) . "/Table/Session.php";
class Library_Session
{
	public $table = null;
	public function __construct()
	{
	    $this->open();	
	}
	
	public function open()
	{
	    
		try {
			if(!$this->table) {
		        $this->table = new Library_Table_Session();
			} 
		} catch (Exception $e) {
			var_dump($e->getMessage());
		}

		return TRUE;
	}
	
	public function close()
	{
		$this->table = null;
		
		return TRUE;
	}
	
	public function read($id)
	{
		$this->open();
		$select = $this->table->select()->where('id = ?',$id);
		$row = $this->table->fetchRow($select);
		return $row == null ? '' : $row->data;
	}
	
	public function write($id,$data)
	{
		
		try {
		    $this->open();
		    $access = time();
		    $db = $this->table->getAdapter();
		    $sql = "REPLACE INTO session VALUES ('$id', '$access', '$data')";
		    $db->query($sql);
		} catch (Exception $e) {
			//TODO: log error
			var_dump($e->getMessage(),$e->getFile());
		}
	}
	
	public function delete($id)
	{
		$this->open();
		$where = $table->getAdapter()->quoteInto('id = ?', $id);
		return $this->table->delete($where);
	}
	
	public function gc($max)
	{
	    $this->open();
		$where = $this->table->getAdapter()->quoteInto('access <= ?', (time() - $max) );
	    return $this->table->delete($where);	
	}
}
?>