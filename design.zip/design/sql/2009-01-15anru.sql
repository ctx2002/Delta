-- tip_component, contact, recipie do not have any relation among them,
-- it just a table to store text, and so user can change them later.
-- do no spent time analysis relation among them.

CREATE TABLE IF NOT EXISTS session (
    id char(32) NOT NULL,
    modified int,
    lifetime int,
    data text,
    PRIMARY KEY (id)
) ENGINE = INNODB;

CREATE TABLE IF NOT EXISTS client (
    name varchar (32) NOT NULL,
    password varchar(32) NOT NULL,
    primary key (name)
) ENGINE = INNODB;

INSERT IGNORE INTO client (name,password) VALUE ("admin", md5("admin")); 

CREATE TABLE IF NOT EXISTS tip_component (
    id int not null AUTO_INCREMENT primary key,
    tip_header varchar(128) NOT NULL DEFAULT "",
    tip_body   text,
    tip_title  varchar(64)
);

CREATE TABLE IF NOT EXISTS contact (
    id int not null AUTO_INCREMENT primary key,
    header varchar(128),
    body text
);

CREATE TABLE IF NOT EXISTS recipe (
    id int not null AUTO_INCREMENT primary key,
    name varchar(128),
    body text,
    note text,
    method text
);

CREATE TABLE IF NOT EXISTS header_body (
    id int not null AUTO_INCREMENT primary key,
    header varchar(128),
    body text,
    image varchar(256),
    type enum("faq","news","slimwork","story")
);
-- for story , header is name, story is body
ALTER TABLE `header_body` ADD `title` VARCHAR( 256 ) NOT NULL ;
ALTER TABLE `recipe` ADD `image` VARCHAR( 256 ) NULL ;
ALTER TABLE `header_body` CHANGE `type` `type` ENUM( 'faq', 'news', 'slimwork', 'story' ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL ;
